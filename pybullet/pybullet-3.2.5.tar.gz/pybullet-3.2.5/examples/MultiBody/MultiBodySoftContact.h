#ifndef MULTI_BODY_SOFT_CONTACT_H
#define MULTI_BODY_SOFT_CONTACT_H

class CommonExampleInterface* MultiBodySoftContactCreateFunc(struct CommonExampleOptions& options);

#endif  //MULTI_BODY_SOFT_CONTACT_H
