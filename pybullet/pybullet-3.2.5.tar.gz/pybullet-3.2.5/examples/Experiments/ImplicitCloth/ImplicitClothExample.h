#ifndef IMPLICIT_CLOTH_EXAMPLE_H
#define IMPLICIT_CLOTH_EXAMPLE_H

class CommonExampleInterface* ImplicitClothCreateFunc(struct CommonExampleOptions& options);

#endif  //IMPLICIT_CLOTH_EXAMPLE_H
